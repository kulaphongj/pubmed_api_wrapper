library(testthat)
library(yelpviz)

test_check("yelpviz")